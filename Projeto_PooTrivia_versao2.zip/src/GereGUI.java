import javax.swing.*;
import java.awt.*;
import java.awt.Font;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GereGUI extends JFrame{

    Color corBotao= new Color(229,179,242);
    Color corLetrasBotao= new Color	(86,86,86);
    Color corPerguntas= new Color(242,162,192);
    Color corFundo= new Color(64,61,62);
    private CardLayout cardLayout;
    private JPanel cardPanel;

    public GereGUI(ArrayList<Pergunta> perguntas) {
        Jogo jogo=new Jogo();

        // Adiciona margens à janela
        int marginSize = 100;
        EmptyBorder margin = new EmptyBorder(marginSize, marginSize, marginSize, marginSize);
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(margin);
        // Define a cor do fundo
        contentPanel.setBackground(corFundo);

        setContentPane(contentPanel);

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        //Painel de boas-vindas
        JPanel welcomePanel = getWelcomePanel();

        jogo.tdsrespostas.clear();


        cardPanel.add(welcomePanel, "Welcome");

        createQuestionPanel(jogo,perguntas);


        add(cardPanel);

    }

    private JPanel getWelcomePanel() {

        JPanel welcomePanel = new JPanel(new BorderLayout());
        welcomePanel.setBackground(corFundo);
        JLabel welcomeLabel = new JLabel("Bem-vindo ao POO Trivia!");
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 60));
        welcomeLabel.setForeground(corPerguntas);

        //Painel do Botão Começar
        JPanel buttonPanel = getButtonPanel("Começar");

        welcomePanel.add(welcomeLabel, BorderLayout.CENTER);
        welcomePanel.add(buttonPanel, BorderLayout.SOUTH);
        return welcomePanel;
    }

    private JPanel getButtonPanel(String mensagem) {

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton startButton = new JButton(mensagem);
        buttonPanel.setBackground(corFundo);

        // Define um tamanho específico para o botão
        Dimension buttonSize = new Dimension(300, 60);
        startButton.setPreferredSize(buttonSize);

        // Define o tamanho da fonte do texto no botão
        Font buttonFont = new Font("Times new Roman", Font.BOLD, 23);
        startButton.setFont(buttonFont);

        // definir cor do botão
        startButton.setBackground(corBotao);
        //Define a cor do texto
        startButton.setForeground(corLetrasBotao);


        startButton.addActionListener(e -> cardLayout.next(cardPanel));
        buttonPanel.add(startButton);
        return buttonPanel;
    }

    private void createQuestionPanel(Jogo jogo,ArrayList<Pergunta> perguntas) {
        int jogada=1;

        while(jogada<6){
            int index= jogo.verificacao(perguntas);
            ArrayList<String> respostas =jogo.fazResposta(perguntas,jogada,index);
            JPanel questionPanel = new JPanel(new BorderLayout());
            String perguntaTexto = jogo.fazPergunta(perguntas,jogada,index);
            JLabel questionLabel = new JLabel("<html>" + perguntaTexto + "</html>");
            questionLabel.setFont(new Font("Times New Roman", Font.BOLD,20));
            questionLabel.setForeground(corPerguntas);

            questionPanel.add(questionLabel, BorderLayout.NORTH);
            questionPanel.setBackground(corFundo);

            cardPanel.add(questionPanel, "Question"+jogada);
            JPanel optionsPanel = new JPanel(new GridLayout(respostas.size(), 1));

            for (Object option : respostas) {
                JButton optionButton = new JButton(option.toString());
                optionButton.addActionListener(e -> cardLayout.next(cardPanel));
                optionsPanel.add(optionButton);
                optionButton.setBackground(corBotao);
                optionButton.setForeground(corLetrasBotao);
                questionPanel.add(optionsPanel, BorderLayout.CENTER);
                optionButton.addActionListener(e -> cardLayout.next(cardPanel));
                if (optionButton.getText().equalsIgnoreCase(perguntas.get(index).respostaCerta(jogada))){
                    painelDoResultado(true,perguntas,index);
                }


                else
                    painelDoResultado(false,perguntas,index);

                jogada++;

            }
        }




     //   return questionPanel;
    }

    private void painelDoResultado(Boolean acertou,ArrayList<Pergunta> perguntas,int index) {
        JPanel resultadoLabelsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        resultadoLabelsPanel.setLayout(new BoxLayout(resultadoLabelsPanel, BoxLayout.Y_AXIS));
        JPanel resultadoPainel = new JPanel(new BorderLayout());
        resultadoLabelsPanel.setBackground(corFundo);
        JLabel resultadoLabel;
        JLabel pontuacaoLabel;
        if(acertou){
             resultadoLabel = new JLabel("(:!!!ACERTOU!!!:)");
             pontuacaoLabel= new JLabel("+"+perguntas.get(index).contas()+" PONTOS<3<3");
        }
        else{
            resultadoLabel = new JLabel("); !!!ERROU!!! ;(");
            pontuacaoLabel= new JLabel("+ 0 PONTOS (T_T)");
        }



        resultadoLabel.setHorizontalAlignment(JLabel.CENTER);
        resultadoLabel.setFont(new Font("Times New Roman", Font.BOLD, 60));
        resultadoLabel.setForeground(corPerguntas);

        pontuacaoLabel.setHorizontalAlignment(JLabel.CENTER);
        pontuacaoLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
        pontuacaoLabel.setForeground(corPerguntas);


        resultadoLabelsPanel.add(resultadoLabel);
        resultadoLabelsPanel.add(pontuacaoLabel);


        JPanel buttonPanel = getButtonPanel("Proxima Pergunta");

        resultadoPainel.add(resultadoLabelsPanel, BorderLayout.CENTER);
        resultadoPainel.add(buttonPanel, BorderLayout.SOUTH);

        cardPanel.add(resultadoPainel, "Result5");
    }


}


